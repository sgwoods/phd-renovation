#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define PI 3.141592654

double *dagostino_d (x, n)
  double *x;
  int n;
{
  int i, dcmp(const void*, const void* );
  static double y[2];
  double d, s, t = 0., *xcopy, m2, s1 = 0., s2, mn = 0.0;

  t = 0;
  s1 = 0.;
  mn = 0.0;
 
  if ((xcopy = (double *) malloc (n * sizeof (double))) == NULL)
  {
    fprintf (stderr, "Memory allocation error\n");
    exit (-1);
  }
  for (i = 0; i < n; ++i)
    xcopy[i] = x[i];
  qsort (xcopy, n, sizeof (double), dcmp);
  for (i = 0; i < n; ++i)
  {
    t += xcopy[i] * ((i + 1) - 0.5 * (n + 1));
    mn += xcopy[i];
  }
  m2 = mn / n;
  for (i = 0; i < n; ++i)
    s1 += (xcopy[i] - m2) * (xcopy[i] - m2);
  s2 = s1 / n;
  s = sqrt (s2);
  d = t / (n * n * s);
  /* y[0] = (d - 1. / (2*sqrt (PI))) * sqrt ((double)n) / 0.02998598; */
  y[0] = d;
  y[1] = sqrt((double)n)*(y[0]-0.28209479)/0.02998598;

#ifdef NOISY
  printf ("  TEST4  DAGN   =%10.4f\n", y[0]);
#endif /* NOISY */
  return y;
}
